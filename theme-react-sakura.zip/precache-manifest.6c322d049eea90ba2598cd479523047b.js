self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d0a2b5cbb0640165f5eefa9f5d4b61c8",
    "url": "/index.html"
  },
  {
    "revision": "e29fc3d84906f9cc07de",
    "url": "/static/css/2.69cab34f.chunk.css"
  },
  {
    "revision": "e29fc3d84906f9cc07de",
    "url": "/static/js/2.0447f6c7.chunk.js"
  },
  {
    "revision": "8c878c4cae0046eba87728b61d6abb5b",
    "url": "/static/js/2.0447f6c7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0c38b167d1a1fc941b63",
    "url": "/static/js/main.3a574d82.chunk.js"
  },
  {
    "revision": "c6f78da4b26db0fa7a23",
    "url": "/static/js/runtime-main.ce746bb1.js"
  },
  {
    "revision": "9615b8a55fad086f4e1c9e1b2189a1e1",
    "url": "/static/media/404.9615b8a5.png"
  },
  {
    "revision": "4f1cd0e78f479c26938d29bb8ac84601",
    "url": "/static/media/ayuda.4f1cd0e7.cur"
  },
  {
    "revision": "2dd613cbfcc40b0c16db1f3660db8666",
    "url": "/static/media/next-b.2dd613cb.svg"
  },
  {
    "revision": "468b8ee9c5375dc6d88624d232b1758a",
    "url": "/static/media/normal.468b8ee9.cur"
  },
  {
    "revision": "b9778335b9ccc99dc791721af44b4979",
    "url": "/static/media/sakura.b9778335.svg"
  },
  {
    "revision": "68d4b27592c416786f7475371b5964dd",
    "url": "/static/media/texto.68d4b275.cur"
  }
]);